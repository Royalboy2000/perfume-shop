import { KpiCard } from "@/components/ui/KpiCard";
import { SectionCard } from "@/components/ui/SectionCard";

export default function EmployeeDashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">My shop today</h1>
        <p className="mt-1 text-xs text-slate-400">
          See today&apos;s sales and stock status for your assigned shop. All
          data is scoped to you and your shop only.
        </p>
      </div>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="My sales today"
          value="KSh 820"
          subtitle="+4 tickets"
          trend="up"
        />
        <KpiCard
          title="Shop sales today"
          value="KSh 2,430"
          subtitle="All employees"
          trend="neutral"
        />
        <KpiCard
          title="Low stock"
          value="3 items"
          subtitle="Need attention"
          trend="down"
        />
        <KpiCard
          title="Open orders"
          value="2"
          subtitle="Pending restock"
          trend="neutral"
        />
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <SectionCard
          title="Quick actions"
          description="Mobile-first layout so you can register sales and stock directly from the shop floor."
        >
          <div className="grid gap-2 text-xs sm:grid-cols-2">
            <button className="flex items-center justify-between rounded-2xl border border-brand-500/60 bg-brand-500/20 px-3 py-2.5 text-left font-medium text-slate-50 shadow-md shadow-brand-900/70 transition hover:bg-brand-500/30">
              <span>New sale</span>
              <span className="rounded-full bg-slate-950/40 px-2 py-0.5 text-[10px]">
                POS mode
              </span>
            </button>
            <button className="flex items-center justify-between rounded-2xl border border-slate-700 bg-slate-950/70 px-3 py-2.5 text-left font-medium text-slate-100 transition hover:bg-slate-900">
              <span>Record stock in</span>
              <span className="rounded-full bg-slate-900 px-2 py-0.5 text-[10px] text-slate-400">
                Delivery
              </span>
            </button>
          </div>
        </SectionCard>

        <SectionCard
          title="Low stock (demo)"
          description="Once connected, this list will only show items for your shop."
        >
          <ul className="space-y-2 text-xs">
            <li className="flex items-center justify-between rounded-2xl bg-slate-950/80 px-3 py-2">
              <div>
                <div className="font-medium text-slate-50">Amber Oud 50ml</div>
                <div className="text-[11px] text-slate-400">3 left</div>
              </div>
              <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-300">
                Restock
              </span>
            </li>
            <li className="flex items-center justify-between rounded-2xl bg-slate-950/80 px-3 py-2">
              <div>
                <div className="font-medium text-slate-50">
                  White Musk 100ml
                </div>
                <div className="text-[11px] text-slate-400">1 left</div>
              </div>
              <span className="rounded-full bg-rose-500/15 px-2 py-0.5 text-[10px] font-semibold text-rose-300">
                Critical
              </span>
            </li>
          </ul>
        </SectionCard>
      </div>
    </div>
  );
}
