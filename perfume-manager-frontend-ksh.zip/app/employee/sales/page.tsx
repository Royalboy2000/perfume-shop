import { SectionCard } from "@/components/ui/SectionCard";

type DemoTicket = {
  id: string;
  time: string;
  product: string;
  quantity: number;
  total: string;
};

const demoTickets: DemoTicket[] = [
  {
    id: "#T-209",
    time: "10:14",
    product: "DIOR SAUVAGE EDP",
    quantity: 1,
    total: "KSh 55"
  },
  {
    id: "#T-208",
    time: "09:48",
    product: "CHANEL BLEU",
    quantity: 1,
    total: "KSh 60"
  }
];

export default function EmployeeSalesPage() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">New sale</h1>
        <p className="mt-1 text-xs text-slate-400">
          Register a new sale quickly. Your shop and employee details are fixed
          by your login, so you only choose products and quantities.
        </p>
      </div>

      <SectionCard
        title="Sale form"
        description="Optimized for phones: large tap areas and stacked fields."
      >
        <form className="grid gap-3 text-xs sm:grid-cols-2">
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Shop</label>
            <div className="flex h-10 items-center rounded-xl border border-slate-800 bg-slate-950/70 px-3 text-[11px] text-slate-300">
              G13 • AL FAROUQ (locked to your account)
            </div>
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Product</label>
            <input
              placeholder="Search product"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Quantity</label>
            <input
              type="number"
              placeholder="1"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Price per unit</label>
            <input
              type="number"
              placeholder="55"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Notes</label>
            <textarea
              rows={2}
              placeholder="Optional notes (discount, customer request, etc.)"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="sm:col-span-2 flex gap-2">
            <button
              type="submit"
              className="flex-1 rounded-xl bg-brand-500 px-4 py-2 text-[11px] font-semibold text-white shadow-md shadow-brand-900/60 hover:bg-brand-600"
            >
              Add to ticket
            </button>
            <button
              type="button"
              className="flex-1 rounded-xl border border-slate-700 px-4 py-2 text-[11px] font-semibold text-slate-200 hover:bg-slate-900"
            >
              Complete sale
            </button>
          </div>
        </form>
      </SectionCard>

      <SectionCard
        title="Today&apos;s tickets (demo)"
        description="Example of how your recent sales for this shop will appear."
      >
        <div className="space-y-2 text-xs">
          {demoTickets.map((ticket) => (
            <div
              key={ticket.id}
              className="rounded-2xl border border-slate-800/80 bg-slate-950/80 px-3 py-2"
            >
              <div className="flex items-center justify-between">
                <div className="font-semibold text-slate-50">
                  {ticket.id}
                </div>
                <div className="text-[11px] text-slate-400">
                  {ticket.time}
                </div>
              </div>
              <div className="mt-1 text-[11px] text-slate-300">
                {ticket.quantity} × {ticket.product}
              </div>
              <div className="mt-1 text-[11px] text-slate-400">
                Total: {ticket.total}
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
