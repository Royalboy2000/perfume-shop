import { SectionCard } from "@/components/ui/SectionCard";

type DemoStock = {
  product: string;
  currentStock: number;
  reorderLevel: number;
};

const demoStock: DemoStock[] = [
  { product: "DIOR SAUVAGE EDP 100ml", currentStock: 4, reorderLevel: 5 },
  { product: "CHANEL BLEU 100ml", currentStock: 7, reorderLevel: 5 },
  { product: "VERSACE EROS 50ml", currentStock: 2, reorderLevel: 4 }
];

function stockStatus(row: DemoStock) {
  if (row.currentStock <= row.reorderLevel) return "low";
  if (row.currentStock <= row.reorderLevel + 2) return "warning";
  return "ok";
}

export default function EmployeeStockPage() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">Stock</h1>
        <p className="mt-1 text-xs text-slate-400">
          See current stock for your shop and register incoming deliveries.
        </p>
      </div>

      <SectionCard
        title="Current stock (demo)"
        description="Inventory for your shop only, based on the INVENTORY SHEET."
      >
        <div className="space-y-2 text-xs">
          {demoStock.map((row) => {
            const status = stockStatus(row);
            return (
              <div
                key={row.product}
                className="rounded-2xl border border-slate-800/80 bg-slate-950/80 px-3 py-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="font-semibold text-slate-50">
                    {row.product}
                  </div>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                      status === "ok"
                        ? "bg-emerald-500/15 text-emerald-300"
                        : status === "warning"
                        ? "bg-amber-500/15 text-amber-300"
                        : "bg-rose-500/15 text-rose-300"
                    }`}
                  >
                    {status === "ok"
                      ? "OK"
                      : status === "warning"
                      ? "Near reorder"
                      : "Low"}
                  </span>
                </div>
                <div className="mt-1 flex justify-between text-[11px] text-slate-300">
                  <span>Current: {row.currentStock}</span>
                  <span>Reorder: {row.reorderLevel}</span>
                </div>
              </div>
            );
          })}
        </div>
      </SectionCard>

      <SectionCard
        title="Record stock in"
        description="When you receive new units in this shop, register them here."
      >
        <form className="grid gap-3 text-xs sm:grid-cols-2">
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Date</label>
            <input
              type="date"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Product</label>
            <input
              placeholder="Search product"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Quantity received</label>
            <input
              type="number"
              placeholder="e.g. 5"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Notes</label>
            <input
              placeholder="Optional notes"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="sm:col-span-2 flex justify-end">
            <button
              type="submit"
              className="rounded-xl bg-brand-500 px-4 py-2 text-[11px] font-semibold text-white shadow-md shadow-brand-900/60 hover:bg-brand-600"
            >
              Save stock in
            </button>
          </div>
        </form>
      </SectionCard>
    </div>
  );
}
