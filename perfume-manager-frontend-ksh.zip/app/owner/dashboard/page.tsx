import { KpiCard } from "@/components/ui/KpiCard";
import { SectionCard } from "@/components/ui/SectionCard";

const mockSalesByDay = [
  { label: "Mon", value: 3400 },
  { label: "Tue", value: 4100 },
  { label: "Wed", value: 3800 },
  { label: "Thu", value: 5200 },
  { label: "Fri", value: 6100 },
  { label: "Sat", value: 7400 },
  { label: "Sun", value: 2950 }
];

const maxSalesValue = Math.max(...mockSalesByDay.map((d) => d.value));

export default function OwnerDashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">
          All shops overview
        </h1>
        <p className="mt-1 text-xs text-slate-400">
          Track total sales, inventory health and employee performance across
          every shop.
        </p>
      </div>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          title="Sales Today"
          value="KSh 3,240"
          subtitle="+12% vs yesterday"
          trend="up"
        />
        <KpiCard
          title="Sales This Month"
          value="KSh 54,980"
          subtitle="+8% vs last month"
          trend="up"
        />
        <KpiCard
          title="Total Shops"
          value="4"
          subtitle="All active locations"
          trend="neutral"
        />
        <KpiCard
          title="Low Stock Items"
          value="9"
          subtitle="< reorder level"
          trend="down"
        />
      </section>

      <div className="grid gap-4 lg:grid-cols-3">
        <SectionCard
          title="Sales by day (demo)"
          description="This will be connected to your SALES sheet. For now we show sample data."
        >
          <div className="mt-2 grid grid-cols-7 gap-2 text-center text-[11px] text-slate-400">
            {mockSalesByDay.map((d) => {
              const height = (d.value / maxSalesValue) * 96;
              return (
                <div
                  key={d.label}
                  className="flex flex-col items-center justify-end gap-1 rounded-2xl bg-slate-950/80 px-1.5 py-2"
                >
                  <div
                    className="w-2 rounded-full bg-gradient-to-t from-brand-500 to-sky-400"
                    style={{ height: `${Math.max(16, height)}px` }}
                  />
                  <span>{d.label}</span>
                </div>
              );
            })}
          </div>
        </SectionCard>

        <SectionCard
          title="Low stock products (demo)"
          description="Once INVENTORY is connected, this will show real alerts per shop."
        >
          <ul className="mt-1 space-y-2 text-xs">
            <li className="flex items-center justify-between rounded-2xl bg-slate-950/80 px-3 py-2">
              <div>
                <div className="font-medium text-slate-50">Oud Royal 50ml</div>
                <div className="text-[11px] text-slate-400">Shop 1 • 4 left</div>
              </div>
              <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-300">
                Restock soon
              </span>
            </li>
            <li className="flex items-center justify-between rounded-2xl bg-slate-950/80 px-3 py-2">
              <div>
                <div className="font-medium text-slate-50">Musk Noir 100ml</div>
                <div className="text-[11px] text-slate-400">Shop 3 • 2 left</div>
              </div>
              <span className="rounded-full bg-rose-500/15 px-2 py-0.5 text-[10px] font-semibold text-rose-300">
                Critical
              </span>
            </li>
          </ul>
        </SectionCard>
      </div>
    </div>
  );
}
