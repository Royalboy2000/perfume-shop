import { SectionCard } from "@/components/ui/SectionCard";

type DemoEmployee = {
  id: string;
  name: string;
  shop: string;
  role: string;
  contact: string;
};

const demoEmployees: DemoEmployee[] = [
  { id: "E001", name: "OMAR YUSUF", shop: "G13 • AL FAROUQ", role: "Cashier", contact: "0711 223 344" },
  { id: "E002", name: "LEILA MANSOOR", shop: "F14 • DIAMOND PLAZA", role: "Manager", contact: "0711 442 233" },
  { id: "E003", name: "KHALID HASSAN", shop: "B15 • AL HAQ", role: "Sales", contact: "0700 112 233" },
  { id: "E004", name: "AHMED ALI", shop: "G13 • AL FAROUQ", role: "Sales", contact: "0711 998 877" }
];

export default function OwnerEmployeesPage() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">Employees</h1>
        <p className="mt-1 text-xs text-slate-400">
          Manage employee accounts and shop assignments. Only the owner can see
          contact information for each employee.
        </p>
      </div>

      <SectionCard
        title="Create employee account"
        description="Create a new employee, assign their shop and role, and set an initial login."
      >
        <form className="grid gap-3 text-xs sm:grid-cols-3">
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Employee ID</label>
            <input
              placeholder="E006"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Full name</label>
            <input
              placeholder="Employee full name"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Shop</label>
            <select className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none focus:border-brand-500">
              <option>Select shop</option>
              <option>G13 • AL FAROUQ</option>
              <option>B15 • AL HAQ</option>
              <option>F14 • DIAMOND PLAZA</option>
              <option>H22 • SUPER SCENT</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Role</label>
            <input
              placeholder="e.g. Cashier, Sales"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Contact</label>
            <input
              placeholder="Phone number"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Username</label>
            <input
              placeholder="Username for login"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-1">
            <label className="text-[11px] text-slate-300">Temporary password</label>
            <input
              type="password"
              placeholder="Set a temporary password"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="sm:col-span-3 flex justify-end">
            <button
              type="submit"
              className="rounded-xl bg-brand-500 px-4 py-2 text-[11px] font-semibold text-white shadow-md shadow-brand-900/60 hover:bg-brand-600"
            >
              Save employee
            </button>
          </div>
        </form>
      </SectionCard>

      <SectionCard
        title="Employees list"
        description="Overview of all employees with their assigned shop and contact details."
      >
        <div className="grid gap-2 sm:grid-cols-2">
          {demoEmployees.map((emp) => (
            <div
              key={emp.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-800/80 bg-slate-950/80 p-3 text-xs"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-[11px] uppercase tracking-[0.18em] text-slate-500">
                    {emp.id}
                  </div>
                  <div className="text-sm font-semibold text-slate-50">
                    {emp.name}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">
                    {emp.role} • {emp.shop}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">
                    Contact: {emp.contact}
                  </div>
                </div>
                <button className="rounded-xl border border-slate-700 px-3 py-1 text-[11px] text-slate-200 hover:bg-slate-900">
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
