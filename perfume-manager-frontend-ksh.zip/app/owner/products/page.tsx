import { SectionCard } from "@/components/ui/SectionCard";

type DemoProduct = {
  id: string;
  name: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  reorderLevel: number;
};

const demoProducts: DemoProduct[] = [
  {
    id: "P001",
    name: "DIOR SAUVAGE EDP",
    category: "Perfume",
    costPrice: 25,
    sellingPrice: 55,
    reorderLevel: 5
  },
  {
    id: "P002",
    name: "CHANEL BLEU",
    category: "Perfume",
    costPrice: 30,
    sellingPrice: 60,
    reorderLevel: 5
  },
  {
    id: "P003",
    name: "VERSACE EROS",
    category: "Perfume",
    costPrice: 20,
    sellingPrice: 45,
    reorderLevel: 4
  }
];

export default function OwnerProductsPage() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">Products</h1>
        <p className="mt-1 text-xs text-slate-400">
          Manage your perfume catalog, pricing and reorder levels. This mirrors
          the Products sheet.
        </p>
      </div>

      <SectionCard
        title="Add / edit product"
        description="Define product details and the reorder level that triggers low-stock alerts."
      >
        <form className="grid gap-3 text-xs sm:grid-cols-3">
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Product ID</label>
            <input
              placeholder="P006"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Product name</label>
            <input
              placeholder="Perfume name"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Category</label>
            <input
              placeholder="e.g. Perfume"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Cost price</label>
            <input
              type="number"
              placeholder="25"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Selling price</label>
            <input
              type="number"
              placeholder="55"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Reorder level</label>
            <input
              type="number"
              placeholder="5"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="sm:col-span-3 flex justify-end">
            <button
              type="submit"
              className="rounded-xl bg-brand-500 px-4 py-2 text-[11px] font-semibold text-white shadow-md shadow-brand-900/60 hover:bg-brand-600"
            >
              Save product
            </button>
          </div>
        </form>
      </SectionCard>

      <SectionCard
        title="Product catalog (demo)"
        description="Example layout for your perfume list. Connect this to the Products sheet later."
      >
        <div className="grid gap-2 sm:grid-cols-2">
          {demoProducts.map((product) => (
            <div
              key={product.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-800/80 bg-slate-950/80 p-3 text-xs"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-[11px] uppercase tracking-[0.18em] text-slate-500">
                    {product.id}
                  </div>
                  <div className="text-sm font-semibold text-slate-50">
                    {product.name}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">
                    Category: {product.category}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">
                    Cost: KSh {product.costPrice.toFixed(2)} • Selling: KSh 
                    {product.sellingPrice.toFixed(2)}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">
                    Reorder level: {product.reorderLevel}
                  </div>
                </div>
                <button className="rounded-xl border border-slate-700 px-3 py-1 text-[11px] text-slate-200 hover:bg-slate-900">
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
