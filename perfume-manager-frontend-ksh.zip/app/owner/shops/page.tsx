import { SectionCard } from "@/components/ui/SectionCard";

type DemoShop = {
  id: string;
  name: string;
  manager: string;
};

const demoShops: DemoShop[] = [
  { id: "G13", name: "AL FAROUQ", manager: "OMAR YUSUF" },
  { id: "B15", name: "AL HAQ", manager: "KHALID HASSAN" },
  { id: "F14", name: "DIAMOND PLAZA", manager: "LEILA MANSOOR" },
  { id: "H22", name: "SUPER SCENT", manager: "FARAH MOHAMED" }
];

export default function OwnerShopsPage() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">Shops</h1>
        <p className="mt-1 text-xs text-slate-400">
          Manage all registered shops from the SHOPS sheet and assign a
          responsible manager to each.
        </p>
      </div>

      <SectionCard
        title="Register new shop"
        description="Create a new shop and assign its manager. Only the owner can do this."
      >
        <form className="grid gap-3 text-xs sm:grid-cols-3">
          <div className="space-y-1 sm:col-span-1">
            <label className="text-[11px] text-slate-300">Shop ID</label>
            <input
              placeholder="e.g. G13"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-1">
            <label className="text-[11px] text-slate-300">Shop name</label>
            <input
              placeholder="e.g. AL FAROUQ"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-1">
            <label className="text-[11px] text-slate-300">Manager</label>
            <input
              placeholder="Manager name"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="sm:col-span-3 flex justify-end">
            <button
              type="submit"
              className="rounded-xl bg-brand-500 px-4 py-2 text-[11px] font-semibold text-white shadow-md shadow-brand-900/60 hover:bg-brand-600"
            >
              Save shop
            </button>
          </div>
        </form>
      </SectionCard>

      <SectionCard
        title="Existing shops"
        description="Overview of all shops with their current manager."
      >
        <div className="grid gap-2 sm:grid-cols-2">
          {demoShops.map((shop) => (
            <div
              key={shop.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-800/80 bg-slate-950/80 p-3 text-xs"
            >
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-[11px] uppercase tracking-[0.18em] text-slate-500">
                    {shop.id}
                  </div>
                  <div className="text-sm font-semibold text-slate-50">
                    {shop.name}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400">
                    Manager: {shop.manager}
                  </div>
                </div>
                <button className="rounded-xl border border-slate-700 px-3 py-1 text-[11px] text-slate-200 hover:bg-slate-900">
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
