import { SectionCard } from "@/components/ui/SectionCard";

type DemoStockIn = {
  id: string;
  date: string;
  shop: string;
  product: string;
  quantity: number;
  supplier: string;
};

const demoStockIn: DemoStockIn[] = [
  {
    id: "#IN-047",
    date: "2025-11-28",
    shop: "G13 • AL FAROUQ",
    product: "DIOR SAUVAGE EDP",
    quantity: 10,
    supplier: "Main Distributor"
  },
  {
    id: "#IN-046",
    date: "2025-11-27",
    shop: "B15 • AL HAQ",
    product: "CHANEL BLEU",
    quantity: 6,
    supplier: "Main Distributor"
  }
];

export default function OwnerStockInPage() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-slate-50">Stock In</h1>
        <p className="mt-1 text-xs text-slate-400">
          Record incoming stock per shop and product. This reflects the Stock In
          sheet: timestamp, date, shop, product, quantity and supplier.
        </p>
      </div>

      <SectionCard
        title="Record new stock in"
        description="When a delivery arrives, register which shop received which products."
      >
        <form className="grid gap-3 text-xs sm:grid-cols-3">
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Date</label>
            <input
              type="date"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Shop</label>
            <select className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none focus:border-brand-500">
              <option>Select shop</option>
              <option>G13 • AL FAROUQ</option>
              <option>B15 • AL HAQ</option>
              <option>F14 • DIAMOND PLAZA</option>
              <option>H22 • SUPER SCENT</option>
            </select>
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Product</label>
            <input
              placeholder="Search product"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Quantity received</label>
            <input
              type="number"
              placeholder="e.g. 10"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <label className="text-[11px] text-slate-300">Supplier</label>
            <input
              placeholder="Supplier name"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="space-y-1 sm:col-span-3">
            <label className="text-[11px] text-slate-300">Notes</label>
            <textarea
              rows={2}
              placeholder="Optional notes about the delivery"
              className="w-full rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-xs text-slate-50 outline-none placeholder:text-slate-500 focus:border-brand-500"
            />
          </div>
          <div className="sm:col-span-3 flex justify-end">
            <button
              type="submit"
              className="rounded-xl bg-brand-500 px-4 py-2 text-[11px] font-semibold text-white shadow-md shadow-brand-900/60 hover:bg-brand-600"
            >
              Save stock-in record
            </button>
          </div>
        </form>
      </SectionCard>

      <SectionCard
        title="Recent stock in (demo)"
        description="Example layout for deliveries recently added to the Stock In sheet."
      >
        <div className="space-y-2 text-xs">
          {demoStockIn.map((row) => (
            <div
              key={row.id}
              className="rounded-2xl border border-slate-800/80 bg-slate-950/80 px-3 py-2"
            >
              <div className="flex items-center justify-between">
                <div className="font-semibold text-slate-50">{row.id}</div>
                <div className="text-[11px] text-slate-400">{row.date}</div>
              </div>
              <div className="mt-1 text-[11px] text-slate-400">
                {row.shop}
              </div>
              <div className="mt-1 text-[11px] text-slate-300">
                {row.quantity} × {row.product}
              </div>
              <div className="mt-1 text-[11px] text-slate-400">
                Supplier: {row.supplier}
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
